# ClickCraft Website

## Files
- index.html — website structure/content
- style.css — complete design/responsive styling
- script.js — menu, animations, portfolio filters, and contact form

## Before publishing
1. Open `script.js`.
2. Replace `your@email.com` with your real ClickCraft business email.
3. Replace the Instagram/Facebook/TikTok `href="#"` links in `index.html` with your real social links.
4. Replace the concept portfolio items with real client work as you get it.
5. Do not publish testimonials until they come from real clients.

## Run locally
Double-click `index.html` or open it in a browser.

## Free hosting
You can publish these files with GitHub Pages, Netlify, or another static hosting provider.
