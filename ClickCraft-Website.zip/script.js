const menuToggle=document.querySelector(".menu-toggle");const navLinks=document.querySelector(".nav-links");
menuToggle?.addEventListener("click",()=>{const open=navLinks.classList.toggle("open");menuToggle.setAttribute("aria-expanded",open)});
document.querySelectorAll(".nav-links a").forEach(a=>a.addEventListener("click",()=>{navLinks.classList.remove("open");menuToggle?.setAttribute("aria-expanded","false")}));

const glow=document.querySelector(".cursor-glow");
window.addEventListener("pointermove",e=>{if(glow){glow.style.left=e.clientX+"px";glow.style.top=e.clientY+"px"}});

const observer=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add("visible")})},{threshold:.12});
document.querySelectorAll(".reveal").forEach(el=>observer.observe(el));

const filters=document.querySelectorAll(".filter"),projects=document.querySelectorAll(".project");
filters.forEach(filter=>filter.addEventListener("click",()=>{filters.forEach(f=>f.classList.remove("active"));filter.classList.add("active");const value=filter.dataset.filter;projects.forEach(p=>{p.classList.toggle("hidden",value!=="all"&&p.dataset.category!==value)})}));

document.querySelectorAll('a[href^="#"]').forEach(link=>link.addEventListener("click",e=>{const target=document.querySelector(link.getAttribute("href"));if(target){e.preventDefault();target.scrollIntoView({behavior:"smooth",block:"start"})}}));

const form=document.getElementById("contactForm"),status=document.getElementById("formStatus");
form?.addEventListener("submit",e=>{
  e.preventDefault();
  const data=new FormData(form);
  const subject=encodeURIComponent(`ClickCraft inquiry — ${data.get("business")}`);
  const body=encodeURIComponent(
`Name: ${data.get("name")}
Business: ${data.get("business")}
Email: ${data.get("email")}
Service: ${data.get("service")}
Budget: ${data.get("budget")||"Not specified"}

Message:
${data.get("message")}`);
  // Replace the email address below with your real ClickCraft business email.
  window.location.href=`mailto:your@email.com?subject=${subject}&body=${body}`;
  status.textContent="Your email app should open with the request filled in. Replace the placeholder business email in script.js with your real email.";
});

document.getElementById("year").textContent=new Date().getFullYear();